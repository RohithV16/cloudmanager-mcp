// getCredentials.js
import fetch from 'node-fetch';

const url = 'https://ims-na1.adobelogin.com/ims/token/v3';
const client_id = '76f2cda04bfe472aa767d1f807d8cdc7';
const client_secret = 'p8e-p9ACbeE3VMeSKAgBbKALypcLr8OP3S5d';
const scope = 'openid,AdobeID,additional_info.projectedProductContext,read_organizations,read_pc.dma_aem_ams,target_sdk,additional_info.roles';

export async function getAdobeCredentials() {
    const body = new URLSearchParams();
    body.append('grant_type', 'client_credentials');
    body.append('client_id', client_id);
    body.append('client_secret', client_secret);
    body.append('scope', scope);

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: body.toString()
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP error! Status: ${response.status}, Details: ${errorText}`);
        }

        const data = await response.json();
        // console.log(data.access_token);
        return data.access_token;
    } catch (error) {
        console.error('Error fetching Adobe credentials:', error);
        throw error; // Re-throw the error for further handling
    }
}

// Call the function to get credentials when the script is executed
getAdobeCredentials();