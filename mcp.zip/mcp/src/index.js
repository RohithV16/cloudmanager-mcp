import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { z } from "zod";
import { getAdobeCredentials } from "./authentication/cloudmanagertoken.mjs";
import { triggerPipeline, getPipelineStatus } from "./cloudmanager/pipeline.js";
import express from "express";

const app = express();

const server = new McpServer({
  name: "CloudManagerMCP",
  version: "1.0.0"
});

server.tool("add",
  { a: z.number(), b: z.number() },
  async ({ a, b }) => ({
    content: [{ type: "text", text: String(a + b) }]
  })
);

server.tool("triggerPipeline",
  {
    programId: z.string().describe("The Cloud Manager program ID"),
    pipelineId: z.string().describe("The ID of the pipeline to trigger")
  },
  async ({ programId, pipelineId }) => {
    try {
      const accessToken = await getAdobeCredentials();
      console.log("accessToken",accessToken);
      const result = await triggerPipeline({ programId, pipelineId, accessToken });
      
      return {
        content: [
          { 
            type: "text", 
            text: `Pipeline triggered successfully!\nExecution ID: ${result.executionId}\nStatus: ${result.status}`
          }
        ]
      };
    } catch (error) {
      return {
        content: [
          { 
            type: "text", 
            text: `Failed to trigger pipeline: ${error.message}`
          }
        ]
      };
    }
  }
);

let transport = null;

app.get("/sse", (req, res) => {
  transport = new SSEServerTransport("/messages", res);
  server.connect(transport);
});

app.post("/messages", (req, res) => {
  if (transport) {
    transport.handlePostMessage(req, res);
  }
});

app.listen(3000);