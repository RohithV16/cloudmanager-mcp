import fetch from 'node-fetch';

const CLOUD_MANAGER_API = 'https://cloudmanager.adobe.io/api';

export async function triggerPipeline({ programId, pipelineId, accessToken }) {
    try {
        const response = await fetch(`${CLOUD_MANAGER_API}/program/${programId}/pipeline/${pipelineId}/execution`, {
            method: 'PUT',
            headers: {
                'Authorization': `${accessToken}`,
                'x-gw-ims-org-id': '1D6365C453A162840A490D45@AdobeOrg',
                'x-api-key': '76f2cda04bfe472aa767d1f807d8cdc7',
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Failed to trigger pipeline. Status: ${response.status}, Details: ${errorText}`);
        }

        const data = await response.json();
        return {
            executionId: data.id,
            status: data.status,
            trigger: data.trigger
        };
    } catch (error) {
        console.error('Error triggering pipeline:', error);
        throw error;
    }
}

export async function getPipelineStatus({ programId, pipelineId, executionId, accessToken }) {
    try {
        const response = await fetch(`${CLOUD_MANAGER_API}/program/${programId}/pipeline/${pipelineId}/execution/${executionId}`, {
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'x-gw-ims-org-id': process.env.IMS_ORG_ID,
                'x-api-key': process.env.API_KEY
            }
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Failed to get pipeline status. Status: ${response.status}, Details: ${errorText}`);
        }

        return await response.json();
    } catch (error) {
        console.error('Error getting pipeline status:', error);
        throw error;
    }
} 